-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 23, 2024 at 02:51 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `grading management`
--

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `id` int(11) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `status` enum('Present','Absent','Late') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`id`, `student_id`, `date`, `status`) VALUES
(1, 3, '2024-09-01', 'Late'),
(2, 3, '2024-09-24', 'Present'),
(3, 3, '2024-09-24', 'Late'),
(4, 8, '2024-08-21', 'Present');

-- --------------------------------------------------------

--
-- Table structure for table `class_records`
--

CREATE TABLE `class_records` (
  `id` int(11) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `subject` varchar(100) DEFAULT NULL,
  `written_exam` decimal(5,2) DEFAULT NULL,
  `performance_task` decimal(5,2) DEFAULT NULL,
  `quarterly_exam` decimal(5,2) DEFAULT NULL,
  `final_grade` decimal(5,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `final_grades`
--

CREATE TABLE `final_grades` (
  `id` int(11) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `final_grade` decimal(5,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `form14_final_grades`
--

CREATE TABLE `form14_final_grades` (
  `form14Id` int(11) NOT NULL,
  `schoolName` varchar(255) NOT NULL,
  `learnerName` varchar(255) NOT NULL,
  `gradeLevel` varchar(10) NOT NULL,
  `section` varchar(50) NOT NULL,
  `schoolYear` varchar(9) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `firstQuarterGrade` int(11) DEFAULT NULL,
  `secondQuarterGrade` int(11) DEFAULT NULL,
  `thirdQuarterGrade` int(11) DEFAULT NULL,
  `fourthQuarterGrade` int(11) DEFAULT NULL,
  `finalGrade` int(11) DEFAULT NULL,
  `totalScore` int(11) DEFAULT NULL,
  `highestPossibleScore` int(11) DEFAULT NULL,
  `highestScore` int(11) DEFAULT NULL,
  `lowestScore` int(11) DEFAULT NULL,
  `averageMean` int(11) DEFAULT NULL,
  `mps` int(11) DEFAULT NULL,
  `numStudentsGetting75PL` int(11) DEFAULT NULL,
  `percentageOfStudentsGetting75PL` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `form137_card`
--

CREATE TABLE `form137_card` (
  `form137Id` int(11) NOT NULL,
  `learnerName` varchar(255) NOT NULL,
  `gradeLevel` varchar(10) NOT NULL,
  `section` varchar(50) NOT NULL,
  `schoolYear` varchar(9) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `teacherName` varchar(100) NOT NULL,
  `schoolId` int(11) DEFAULT NULL,
  `remark` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `grades`
--

CREATE TABLE `grades` (
  `id` int(11) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `written_exam` decimal(5,2) DEFAULT NULL,
  `performance_task` decimal(5,2) DEFAULT NULL,
  `quarterly_exam` decimal(5,2) DEFAULT NULL,
  `final_grade` decimal(5,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `reports`
--

CREATE TABLE `reports` (
  `id` int(11) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `final_grade` decimal(5,2) DEFAULT NULL,
  `form_2` varchar(255) DEFAULT NULL,
  `form_137` varchar(255) DEFAULT NULL,
  `form_14` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `schedules`
--

CREATE TABLE `schedules` (
  `id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `start_time` datetime NOT NULL,
  `end_time` datetime NOT NULL,
  `alert_sent` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `schedules`
--

INSERT INTO `schedules` (`id`, `teacher_id`, `title`, `description`, `start_time`, `end_time`, `alert_sent`) VALUES
(1, 4, 'Orientation', 'Teachers meeting', '2024-08-01 17:58:00', '2024-08-01 18:00:00', 0),
(2, 6, 'wdasdasdsasdasdas', 'asdasd', '2024-08-09 19:28:00', '2024-08-01 07:33:00', 0),
(3, 8, 'hj', 'ghf', '2024-08-14 10:30:00', '2024-08-14 11:00:00', 0),
(5, 35, 'Science ', 'Class', '2024-08-22 09:00:00', '2024-08-22 10:00:00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `sf2_attendance_report`
--

CREATE TABLE `sf2_attendance_report` (
  `form2Id` int(11) NOT NULL,
  `schoolId` int(11) NOT NULL,
  `learnerName` varchar(255) NOT NULL,
  `gradeLevel` varchar(10) NOT NULL,
  `learnerAttendanceConversionTool` varchar(50) NOT NULL,
  `section` varchar(50) NOT NULL,
  `schoolYear` varchar(9) NOT NULL,
  `month` varchar(20) NOT NULL,
  `day_01` char(1) DEFAULT NULL,
  `day_02` char(1) DEFAULT NULL,
  `day_03` char(1) DEFAULT NULL,
  `day_04` char(1) DEFAULT NULL,
  `day_05` char(1) DEFAULT NULL,
  `day_06` char(1) DEFAULT NULL,
  `day_07` char(1) DEFAULT NULL,
  `day_08` char(1) DEFAULT NULL,
  `day_09` char(1) DEFAULT NULL,
  `day_10` char(1) DEFAULT NULL,
  `day_11` char(1) DEFAULT NULL,
  `day_12` char(1) DEFAULT NULL,
  `day_13` char(1) DEFAULT NULL,
  `day_14` char(1) DEFAULT NULL,
  `day_15` char(1) DEFAULT NULL,
  `day_16` char(1) DEFAULT NULL,
  `day_17` char(1) DEFAULT NULL,
  `day_18` char(1) DEFAULT NULL,
  `day_19` char(1) DEFAULT NULL,
  `day_20` char(1) DEFAULT NULL,
  `day_21` char(1) DEFAULT NULL,
  `day_22` char(1) DEFAULT NULL,
  `day_23` char(1) DEFAULT NULL,
  `day_24` char(1) DEFAULT NULL,
  `day_25` char(1) DEFAULT NULL,
  `day_26` char(1) DEFAULT NULL,
  `day_27` char(1) DEFAULT NULL,
  `day_28` char(1) DEFAULT NULL,
  `day_29` char(1) DEFAULT NULL,
  `day_30` char(1) DEFAULT NULL,
  `day_31` char(1) DEFAULT NULL,
  `total_present` int(11) DEFAULT NULL,
  `total_absent` int(11) DEFAULT NULL,
  `total_late` int(11) DEFAULT NULL,
  `total_excused` int(11) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sf2_attendance_report`
--

INSERT INTO `sf2_attendance_report` (`form2Id`, `schoolId`, `learnerName`, `gradeLevel`, `learnerAttendanceConversionTool`, `section`, `schoolYear`, `month`, `day_01`, `day_02`, `day_03`, `day_04`, `day_05`, `day_06`, `day_07`, `day_08`, `day_09`, `day_10`, `day_11`, `day_12`, `day_13`, `day_14`, `day_15`, `day_16`, `day_17`, `day_18`, `day_19`, `day_20`, `day_21`, `day_22`, `day_23`, `day_24`, `day_25`, `day_26`, `day_27`, `day_28`, `day_29`, `day_30`, `day_31`, `total_present`, `total_absent`, `total_late`, `total_excused`, `remarks`) VALUES
(1, 2147483647, 'Aria', '12th', '', 'IT908', '2024', '12', 'P', 'L', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, 0, 0, 0, 'Transfered in'),
(2, 2147483647, 'Liam', '10th', '', 'IT396', '2021', '12', 'L', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 1, 0, NULL),
(3, 2147483647, 'Liam', '10th', '', 'IT396', '2021', '', 'L', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 1, 0, 'Passed'),
(4, 2147483647, 'Ava', '12th', '', 'IT455', '2021', '2024-01', 'P', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, 0, 0, 0, ''),
(5, 1234567890, 'Emma', '7th', '', 'IT882', '2022-2023', '2024-07', 'L', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 1, 0, ''),
(8, 2147483647, 'Aria', '12th', '', 'IT908', '2023-2024', '2024-07', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, 0, ''),
(9, 2147483647, 'Aria', '12th', '', 'IT556', '2022-2023', '2024-02', 'P', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, 0, 0, 0, ''),
(10, 2147483647, 'Aria', '12th', '', 'IT556', '2022-2023', '2024-02', 'P', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, 0, 0, 0, ''),
(11, 2147483647, 'Aria', '12th', '', 'IT556', '2022-2023', '2024-07', 'P', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, 0, 0, 0, ''),
(12, 2147483647, 'Ava', '12th', '', 'IT455', '2024-2025', '2024-11', 'L', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 1, 0, ''),
(14, 2147483647, 'Aria', '12th', '', 'IT556', '2022-2023', '2024-01', '', 'A', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 1, 0, 0, ''),
(15, 2147483647, 'Aria', '12th', '', 'IT556', '2022-2023', '2024-07', 'P', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, 0, 0, 0, ''),
(16, 2147483647, 'Aria', '12th', '', 'IT556', '2022-2023', '2024-07', 'P', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, 0, 0, 0, ''),
(17, 2147483647, 'Aria', '12th', '', 'IT556', '2022-2023', '2024-12', 'P', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, 0, 0, 0, ''),
(18, 1231231231, 'Normal', '8th', '', '123', '2022-2023', '2024-01', 'A', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 1, 0, 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(11) NOT NULL,
  `learners_name` varchar(255) DEFAULT NULL,
  `region` varchar(100) DEFAULT NULL,
  `division` varchar(100) DEFAULT NULL,
  `school_id` varchar(100) DEFAULT NULL,
  `school_year` varchar(20) DEFAULT NULL,
  `gender` enum('Male','Female') DEFAULT NULL,
  `subject` varchar(100) DEFAULT NULL,
  `section` varchar(36) NOT NULL,
  `grade` varchar(36) NOT NULL,
  `school_level` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `learners_name`, `region`, `division`, `school_id`, `school_year`, `gender`, `subject`, `section`, `grade`, `school_level`) VALUES
(3, 'Aria', '7', '7', '3987123412', '2024-2025', 'Female', 'Science', 'IT908', '12th', 'SHS'),
(4, 'Aria', '7', '7', '3987123412', '2024-2025', 'Female', 'Science', 'IT556', '12th', 'SHS'),
(5, 'Liam', '6', '5', '2938471298', '2023-2024', 'Male', 'Math', 'IT396', '10th', 'JHS'),
(6, 'Noah', '8', '9', '5678234567', '2024-2025', 'Male', 'English', 'IT215', '11th', 'SHS'),
(7, 'Olivia', '9', '3', '3456712345', '2022-2023', 'Female', 'Science', 'IT685', '9th', 'JHS'),
(8, 'Emma', '5', '4', '1234567890', '2023-2024', 'Female', 'History', 'IT882', '7th', 'JHS'),
(9, 'Ava', '3', '2', '8765432109', '2024-2025', 'Female', 'Math', 'IT455', '12th', 'SHS'),
(10, 'Sophia', '2', '1', '2345678901', '2022-2023', 'Female', 'English', 'IT431', '8th', 'JHS'),
(11, 'Isabella', '4', '6', '3456789012', '2023-2024', 'Female', 'Science', 'IT691', '11th', 'SHS'),
(12, 'Mia', '10', '8', '4567890123', '2024-2025', 'Female', 'Math', 'IT263', '10th', 'JHS'),
(13, 'Lucas', '7', '7', '5678901234', '2023-2024', 'Male', 'History', 'IT940', '9th', 'JHS'),
(16, 'maria', '7', 'cebu', '303031', '2024-2025', 'Male', '', '', '7th', ''),
(18, 'maria', '7', 'cebu', '303031', '2024-2025', 'Female', 'math', '', '10th', ''),
(19, 'mae', '7', 'cebu', '303031', '2024-2025', 'Female', 'english', '', '9th', ''),
(20, 'Normal', '7', 'Cebu', '1231231231', '2024', 'Male', 'math', '123', '8th', 'SHS'),
(21, '123', '123', '123', '123', '123', 'Female', '123', '123', '7th', 'JHS'),
(22, '', '', '', '', '', 'Male', '', '', '7th', '');

-- --------------------------------------------------------

--
-- Table structure for table `student_grades`
--

CREATE TABLE `student_grades` (
  `id` int(11) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `subject_id` int(11) DEFAULT NULL,
  `written_exam` float DEFAULT NULL,
  `performance_task` float DEFAULT NULL,
  `quarterly_exam` float DEFAULT NULL,
  `final_grade` float DEFAULT NULL,
  `highest_possible_score` decimal(5,2) DEFAULT NULL,
  `lowest_score` decimal(5,2) DEFAULT NULL,
  `average_mean` decimal(5,2) DEFAULT NULL,
  `mps` decimal(5,2) DEFAULT NULL,
  `students_75_percent` int(11) DEFAULT NULL,
  `percentage_75_percent` decimal(5,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student_grades`
--

INSERT INTO `student_grades` (`id`, `student_id`, `subject_id`, `written_exam`, `performance_task`, `quarterly_exam`, `final_grade`, `highest_possible_score`, `lowest_score`, `average_mean`, `mps`, `students_75_percent`, `percentage_75_percent`) VALUES
(20, 3, 1, 85, 90, 88, 87, NULL, NULL, NULL, NULL, NULL, NULL),
(21, 6, 1, 89, 90, 76, 100, NULL, NULL, NULL, NULL, NULL, NULL),
(22, 3, 1, 111, 11, 11, 41, NULL, NULL, NULL, NULL, NULL, NULL),
(23, 3, 1, 12, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL),
(24, 7, 1, 89, 89, 79, 87, NULL, NULL, NULL, NULL, NULL, NULL),
(25, 11, 2, 78, 70, 89, 76.2, NULL, NULL, NULL, NULL, NULL, NULL),
(26, 16, 1, 90, 87, 87, 87.9, NULL, NULL, NULL, NULL, NULL, NULL),
(27, 18, 1, 111, 11, 11, 41, NULL, NULL, NULL, NULL, NULL, NULL),
(28, 4, 2, 1, 0, 0, 0.3, NULL, NULL, NULL, NULL, NULL, NULL),
(29, 5, 1, 1, 0, 0, 0.3, NULL, NULL, NULL, NULL, NULL, NULL),
(30, 20, 2, 89, 86, 88, 87.3, NULL, NULL, NULL, NULL, NULL, NULL),
(31, 4, 1, 123, 123, 123, 123, NULL, NULL, NULL, NULL, NULL, NULL),
(32, 8, 1, 90, 89, 91, 89.7, NULL, NULL, NULL, NULL, NULL, NULL),
(33, 7, 2, 123, 123, 123, 123, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE `subjects` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `student_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`id`, `name`, `description`, `student_id`) VALUES
(1, 'Mathematics', 'Math course description', NULL),
(2, 'English', 'English course description', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `userid` int(11) NOT NULL,
  `name` varchar(36) NOT NULL,
  `username` varchar(36) NOT NULL,
  `password` varchar(36) NOT NULL,
  `address` varchar(36) NOT NULL,
  `role` varchar(36) NOT NULL,
  `confirm_password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`userid`, `name`, `username`, `password`, `address`, `role`, `confirm_password`) VALUES
(2, 'bernadet123', 'bernadet123', '', 'bernadet@gmail.com', 'user', ''),
(3, 'Mariebel', 'Mariebel123', '12345', 'Mariebel@gmail.com', '', ''),
(4, 'John Kennedy', 'Admin', '', 'JohnKennedy@gmail.com', 'admin', ''),
(5, 'joel', 'joel123', '123', 'joel@gmail.com', 'Admin', ''),
(6, 'Moses', 'moses123', '123', 'moses@gmail.com', 'Admin', ''),
(7, 'Admin', 'Admin123', '123', 'Admin@gmail.com', 'Admin', ''),
(8, 'moses', 'mm', '12', 'moses@gmail.com', 'Teacher', ''),
(9, 'Marlyn', 'Marlyn@gmail.com', '123', 'Marlyn@gmail.com', 'Admin', ''),
(10, 'Anna', 'Anna', 'summer', 'Anna@gmail.com', 'Teacher', ''),
(11, 'Els', 'els', 'snowqueen', 'els@gmail.com', 'Teacher', ''),
(12, 'Jose', 'JN', '123', 'Jose@gmail.com', 'Admin', ''),
(13, 'Test', 'test', '123', 'test@gmail.com', 'Admin', ''),
(14, 'Jake Serotonin', 'jake', '123', 'jakeS@gmail.com', 'Teacher', '123'),
(15, 'asd', 'asd', '123', 'asd@gmail', 'Teacher', ''),
(16, 'asd', 'asd', '123', 'asd@gmail', 'Teacher', ''),
(17, 'asd', 'asd', '123', 'asd@gmail', 'Teacher', '123'),
(18, 'asd', 'asd', '123', 'asd@gmail', 'Admin', ''),
(19, 'asd', 'asd', '123', 'asd@gmail', 'Admin', ''),
(20, 'Jose', 'jose', '123', 'jose@gmail.com', 'Admin', ''),
(21, 'asd', 'asd', '123', 'asd@gmail.com', 'Admin', '123'),
(22, 'Joanna', 'jo', '123', 'Jo@gmail.com', 'Admin', '123'),
(23, 'Kristine', 'Kristine', '123', 'Kristine@gmail.com', 'Teacher', '123'),
(24, 'dasd', 'joana', '123', 'das@gmail.com', 'Admin', '123'),
(25, 'asd', 'asd', '123', 'asd@dd', 'Admin', '123'),
(26, 'test', 'testing12', 'testing3', 'test@gmail.com', 'Admin', 'testing3'),
(27, 'test', 'tes', '12', 'test@g', 'Admin', '12'),
(28, 'testing', 'testing12', '123testing', 'testing@gmail.com', 'Admin', '123testing'),
(29, 'jocelyn', 'jocelyn123', 'jocelyn123', 'jocelyn@gmail.com', 'Admin', 'jocelyn123'),
(30, 'jocelyn', 'jocelyn123', 'jocelyn123', 'jocelyn@gmail.com', 'Admin', 'jocelyn123'),
(31, 'Faith', 'Fathima123', 'fathima123', 'Fathima@gmail.com', 'Teacher', 'fathima123'),
(32, '', 'admin', 'adminpassword', '', 'admin', ''),
(33, '', 'user1', 'user1password', '', 'user', ''),
(34, '', 'user2', 'user2password', '', 'user', ''),
(35, 'Moses Mae', 'mmae.123', 'moses@123', 'moses@gmail.com', 'Teacher', 'moses@123'),
(36, 'Melvic', 'Melvicgreg123', 'melvicgregg123', 'melvicgregg@gmail.com', 'Teacher', 'melvicgregg123');

-- --------------------------------------------------------

--
-- Table structure for table `user_activity_log`
--

CREATE TABLE `user_activity_log` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `action` varchar(255) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_activity_log`
--

INSERT INTO `user_activity_log` (`id`, `username`, `action`, `timestamp`) VALUES
(1, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:48:04'),
(2, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:48:05'),
(3, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:48:05'),
(4, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:48:05'),
(5, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:48:05'),
(6, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:48:06'),
(7, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:48:09'),
(8, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:48:11'),
(9, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:48:13'),
(10, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:48:15'),
(11, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:48:22'),
(12, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:49:08'),
(13, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:49:11'),
(14, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:51:28'),
(15, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:51:31'),
(16, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:51:36'),
(17, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:52:13'),
(18, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:54:26'),
(19, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:54:30'),
(20, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:54:53'),
(21, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:54:53'),
(22, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:55:26'),
(23, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:57:59'),
(24, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:01:18'),
(25, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:01:34'),
(26, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:03:20'),
(27, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:03:44'),
(28, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:05:33'),
(29, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:08:58'),
(30, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:09:03'),
(31, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:18:02'),
(32, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:21:16'),
(33, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:21:23'),
(34, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:21:33'),
(35, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:23:55'),
(36, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:25:37'),
(37, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:25:39'),
(38, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:25:42'),
(39, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:25:44'),
(40, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:25:59'),
(41, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:26:05'),
(42, 'admin', 'Accessed Admin Homepage', '2024-08-20 09:29:08'),
(43, 'user1', 'Logged In', '2024-08-20 09:29:08'),
(44, 'user2', 'Updated Profile', '2024-08-20 09:29:08'),
(45, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:31:09'),
(46, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:34:13'),
(47, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:34:13'),
(48, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:34:15'),
(49, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:34:48'),
(50, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:36:13'),
(51, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:36:18'),
(52, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:37:10'),
(53, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:37:10'),
(54, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:37:10'),
(55, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:38:13'),
(56, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:38:15'),
(57, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:38:17'),
(58, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:38:37'),
(59, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:38:37'),
(60, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:38:37'),
(61, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:39:09'),
(62, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:39:47'),
(63, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:39:51'),
(64, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:39:53');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
  ADD PRIMARY KEY (`id`),
  ADD KEY `student_id` (`student_id`);

--
-- Indexes for table `class_records`
--
ALTER TABLE `class_records`
  ADD PRIMARY KEY (`id`),
  ADD KEY `student_id` (`student_id`);

--
-- Indexes for table `final_grades`
--
ALTER TABLE `final_grades`
  ADD PRIMARY KEY (`id`),
  ADD KEY `student_id` (`student_id`);

--
-- Indexes for table `form14_final_grades`
--
ALTER TABLE `form14_final_grades`
  ADD PRIMARY KEY (`form14Id`);

--
-- Indexes for table `form137_card`
--
ALTER TABLE `form137_card`
  ADD PRIMARY KEY (`form137Id`);

--
-- Indexes for table `grades`
--
ALTER TABLE `grades`
  ADD PRIMARY KEY (`id`),
  ADD KEY `student_id` (`student_id`);

--
-- Indexes for table `reports`
--
ALTER TABLE `reports`
  ADD PRIMARY KEY (`id`),
  ADD KEY `student_id` (`student_id`);

--
-- Indexes for table `schedules`
--
ALTER TABLE `schedules`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sf2_attendance_report`
--
ALTER TABLE `sf2_attendance_report`
  ADD PRIMARY KEY (`form2Id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student_grades`
--
ALTER TABLE `student_grades`
  ADD PRIMARY KEY (`id`),
  ADD KEY `student_id` (`student_id`),
  ADD KEY `subject_id` (`subject_id`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_student_subject` (`student_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`userid`);

--
-- Indexes for table `user_activity_log`
--
ALTER TABLE `user_activity_log`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attendance`
--
ALTER TABLE `attendance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `class_records`
--
ALTER TABLE `class_records`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `final_grades`
--
ALTER TABLE `final_grades`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `form14_final_grades`
--
ALTER TABLE `form14_final_grades`
  MODIFY `form14Id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `form137_card`
--
ALTER TABLE `form137_card`
  MODIFY `form137Id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `grades`
--
ALTER TABLE `grades`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `reports`
--
ALTER TABLE `reports`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `schedules`
--
ALTER TABLE `schedules`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `sf2_attendance_report`
--
ALTER TABLE `sf2_attendance_report`
  MODIFY `form2Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `student_grades`
--
ALTER TABLE `student_grades`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `subjects`
--
ALTER TABLE `subjects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `userid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `user_activity_log`
--
ALTER TABLE `user_activity_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `attendance`
--
ALTER TABLE `attendance`
  ADD CONSTRAINT `attendance_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`);

--
-- Constraints for table `class_records`
--
ALTER TABLE `class_records`
  ADD CONSTRAINT `class_records_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`);

--
-- Constraints for table `final_grades`
--
ALTER TABLE `final_grades`
  ADD CONSTRAINT `final_grades_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`);

--
-- Constraints for table `grades`
--
ALTER TABLE `grades`
  ADD CONSTRAINT `grades_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`);

--
-- Constraints for table `reports`
--
ALTER TABLE `reports`
  ADD CONSTRAINT `reports_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`);

--
-- Constraints for table `student_grades`
--
ALTER TABLE `student_grades`
  ADD CONSTRAINT `student_grades_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`),
  ADD CONSTRAINT `student_grades_ibfk_2` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`);

--
-- Constraints for table `subjects`
--
ALTER TABLE `subjects`
  ADD CONSTRAINT `fk_student_subject` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
